import React from "react";
import {
  FaFilter,
  FaSearch,
  FaTimes,
  FaStar,
  FaSlidersH,
  FaBolt,
  FaMobileAlt,
} from "react-icons/fa";

const iconMap = {
  "Search & Brands": FaSearch,
  Price: FaFilter,
  Memory: FaMobileAlt,
  Storage: FaSlidersH,
  Battery: FaBolt,
  Processor: FaStar,
  Network: FaMobileAlt,
  "Refresh Rate": FaSlidersH,
  Camera: FaMobileAlt,
  Display: FaSearch,
  Build: FaStar,
  OS: FaFilter,
  "Screen Size": FaMobileAlt,
  "Display Type": FaFilter,
  Resolution: FaSearch,
  HDR: FaStar,
  "Smart OS": FaFilter,
  Audio: FaBolt,
  Connectivity: FaMobileAlt,
  Gaming: FaStar,
};
import { useState } from "react";

const ProductFilterSheet = ({
  open,
  onClose,
  onReset,
  onApply,
  title = "Filters",
  subtitle = "Refine products by specifications",
  applyLabel = "Apply filters",
  resultCount,
  sections = [],
  children,
}) => {
  if (!open) return null;
  const [activeSectionIndex, setActiveSectionIndex] = useState(0);

  const handleMobileSectionChange = (index) => {
    setActiveSectionIndex(index);

    const activeSection = sections[activeSectionIndex];
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-0 lg:p-6">
      <button
        type="button"
        className="absolute inset-0 cursor-default bg-slate-950/45 backdrop-blur-[2px]"
        onClick={onClose}
        aria-label="Close filters"
      />
      <section
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="relative flex h-full w-full flex-col overflow-hidden bg-white sm:my-3 sm:h-[calc(100%-1.5rem)] sm:max-w-md lg:h-[min(760px,calc(100vh-80px))] lg:w-[min(1180px,calc(100vw-48px))] lg:max-w-none lg:rounded-[24px] lg:ring-1 lg:ring-slate-200"
      >
        <header className="flex shrink-0 items-center justify-between gap-4 border-b border-slate-100 px-4 py-4 lg:px-6 lg:py-5">
          <div className="flex min-w-0 items-center gap-3 lg:gap-4">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-slate-100 text-slate-600 lg:h-11 lg:w-11">
              <FaFilter className="text-sm" />
            </span>
            <div className="min-w-0">
              <h3 className="text-xl font-black tracking-[-0.02em] text-slate-950 lg:text-2xl">
                {title}
              </h3>
              <p className="mt-1 text-xs font-medium text-slate-500 lg:text-sm">
                {subtitle}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-slate-100 text-slate-600 transition hover:bg-slate-200"
            aria-label="Close filters"
          >
            <FaTimes className="text-sm" />
          </button>
        </header>

        <div className="grid min-h-0 flex-1 lg:grid-cols-[260px_minmax(0,1fr)]">
          <nav className="hidden min-h-0 overflow-y-auto border-r border-slate-100 p-3 lg:block">
            <div className="space-y-1.5">
              {sections.map((section, index) => {
                const isActive = index === 0;
                const Icon = iconMap[section] || FaFilter;
                return (
                  <button
                    key={section}
                    type="button"
                    className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left transition ${
                      isActive
                        ? "bg-blue-50 text-blue-700 ring-1 ring-blue-100"
                        : "text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <span className="flex min-w-0 items-center gap-3">
                      <span
                        className={`grid h-8 w-8 shrink-0 place-items-center rounded-xl text-xs ${
                          isActive
                            ? "bg-blue-600 text-white"
                            : "bg-slate-100 text-slate-500"
                        }`}
                      >
                        <Icon className="text-[11px]" />
                      </span>
                      <span className="truncate text-sm font-bold">
                        {section}
                      </span>
                    </span>
                    {index === 0 ? (
                      <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-blue-100 px-1 text-[9px] font-black text-blue-700">
                        •
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </nav>
          <div className="min-h-0 overflow-y-auto">
            <div className="block px-4 py-3 lg:hidden">
              <select
                value={activeSectionIndex}
                onChange={(e) =>
                  handleMobileSectionChange(parseInt(e.target.value, 10))
                }
                className="w-full appearance-none rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-bold text-slate-900 outline-none"
              >
                {sections.map((section, index) => (
                  <option key={section} value={index}>
                    {section}
                  </option>
                ))}
              </select>
            </div>
            <div className="px-4 py-4 lg:px-6 lg:py-5">{children}</div>
          </div>
        </div>

        <footer className="flex shrink-0 items-center justify-between gap-3 border-t border-slate-100 bg-white/95 px-4 py-3 backdrop-blur lg:px-6 lg:py-4">
          <button
            type="button"
            onClick={onReset}
            className="rounded-xl px-3 py-2.5 text-sm font-bold text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
          >
            Reset all
          </button>
          <button
            type="button"
            onClick={onApply}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-black text-white transition hover:bg-blue-700"
          >
            <FaFilter className="text-[10px]" />
            {applyLabel}
            {resultCount != null ? ` (${resultCount})` : ""}
          </button>
        </footer>
      </section>
    </div>
  );
};

export default ProductFilterSheet;
