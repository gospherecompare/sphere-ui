import React from "react";
import { FaFilter, FaPlus, FaStar, FaSyncAlt, FaTimes } from "react-icons/fa";

const PopularFeatureFilterSheet = ({
  open,
  features = [],
  pendingFeature = "",
  onPendingChange,
  onApply,
  onCancel,
  title = "Popular Features",
  subtitle = "Choose one feature",
  selectionLabel = "All popular features",
  applyLabel = "Apply feature",
}) => {
  if (!open) return null;

  const pendingName =
    features.find((feature) => feature.id === pendingFeature)?.name ||
    selectionLabel;

  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center p-0 sm:items-center sm:p-6">
      <button
        type="button"
        className="absolute inset-0 bg-slate-950/45 backdrop-blur-[2px]"
        aria-label="Close popular features"
        onClick={onCancel}
      />
      <section
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="relative flex max-h-[92dvh] w-full flex-col overflow-hidden bg-white sm:max-h-[82vh] sm:max-w-5xl sm:rounded-[24px] sm:ring-1 sm:ring-slate-200"
      >
        <header className="flex shrink-0 items-start justify-between gap-4 border-b border-slate-100 px-4 py-4 sm:px-6 sm:py-5">
          <div className="flex min-w-0 items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-blue-50 text-blue-600">
              <FaStar className="text-sm" />
            </span>
            <div className="min-w-0">
              <h3 className="text-lg font-black tracking-tight text-slate-950 sm:text-2xl">
                {title}
              </h3>
              <p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">
                {subtitle}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-600 transition hover:bg-slate-200 hover:text-slate-950"
            aria-label="Close popular features"
          >
            <FaTimes />
          </button>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 sm:px-6 sm:py-6">
          <div className="grid gap-4 lg:grid-cols-[15rem_minmax(0,1fr)]">
            <aside className="rounded-2xl bg-slate-50 p-4">
              <span className="block text-[10px] font-extrabold uppercase tracking-[0.16em] text-blue-700">
                Selected
              </span>
              <div className="mt-3 rounded-xl bg-white p-3">
                <span className="block text-[10px] font-extrabold uppercase tracking-[0.12em] text-slate-400">
                  Feature
                </span>
                <span className="mt-1 block text-sm font-bold text-slate-800">
                  {pendingName}
                </span>
              </div>
            </aside>

            <div className="min-w-0">
              <div className="mb-3 flex items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-black text-slate-950 sm:text-base">
                    Choose one feature
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => onPendingChange?.("")}
                  className="inline-flex min-h-9 items-center gap-2 rounded-xl bg-slate-100 px-3 text-xs font-bold text-slate-700 transition hover:bg-slate-200"
                >
                  <FaSyncAlt className="text-[10px]" />
                  Clear
                </button>
              </div>

              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
                {features.map((feature) => {
                  const Icon = feature.icon;
                  const selected = pendingFeature === feature.id;
                  return (
                    <button
                      key={feature.id}
                      type="button"
                      aria-pressed={selected}
                      onClick={() =>
                        onPendingChange?.(selected ? "" : feature.id)
                      }
                      className={`group flex min-h-[72px] min-w-0 items-center gap-3 rounded-2xl px-3.5 py-3 text-left transition ${selected ? "bg-blue-600 text-white" : "bg-slate-50 text-slate-700 hover:bg-blue-50 hover:text-blue-800"}`}
                    >
                      <span
                        className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl text-sm ${selected ? "bg-white/15 text-white" : "bg-white text-blue-600 group-hover:bg-blue-100"}`}
                      >
                        {Icon ? <Icon /> : <FaStar />}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-bold leading-5">
                          {feature.name}
                        </span>
                      </span>
                      <span
                        className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-[10px] ${selected ? "bg-white text-blue-600" : "bg-slate-100 text-slate-400 group-hover:bg-blue-100 group-hover:text-blue-600"}`}
                      >
                        {selected ? "✓" : <FaPlus />}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <footer className="flex shrink-0 items-center justify-end gap-2 border-t border-slate-100 bg-white px-4 py-3 sm:px-6 sm:py-4">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex min-h-11 items-center justify-center rounded-xl bg-slate-100 px-4 text-sm font-bold text-slate-700 transition hover:bg-slate-200"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onApply}
            className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 text-sm font-black text-white transition hover:bg-blue-700"
          >
            <FaFilter className="text-[10px]" />
            {pendingFeature ? applyLabel : "Apply feature"}
          </button>
        </footer>
      </section>
    </div>
  );
};

export default PopularFeatureFilterSheet;
